package com.samar.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

/** Online-first chat with automatic on-device fallback. */
object SamarChatRouter {
    // Add your deployed HTTPS backend URL here. Keep empty until configured.
    // Never put an AI provider secret/API key in the Android app.
    private const val SAMAR_CHAT_ENDPOINT = ""
    private const val CONNECT_TIMEOUT_MS = 5000
    private const val READ_TIMEOUT_MS = 12000
    private val executor = Executors.newSingleThreadExecutor()

    enum class Mode { ONLINE, OFFLINE }
    data class ChatResult(val reply: String, val mode: Mode, val detail: String)

    fun hasInternet(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork
            if (network == null) false else {
                val caps = cm.getNetworkCapabilities(network)
                caps != null &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        } catch (_: Exception) { false }
    }

    fun currentMode(context: Context): Mode =
        if (hasInternet(context) && SAMAR_CHAT_ENDPOINT.isNotBlank()) Mode.ONLINE else Mode.OFFLINE

    fun send(context: Context, message: String, callback: (ChatResult) -> Unit) {
        val appContext = context.applicationContext
        executor.execute {
            val onlineAvailable = hasInternet(appContext) && SAMAR_CHAT_ENDPOINT.isNotBlank()
            val result = if (onlineAvailable) {
                requestOnline(message) ?: ChatResult(
                    OfflineChatEngine.reply(appContext, message), Mode.OFFLINE,
                    "Cloud request failed; switched to offline automatically."
                )
            } else {
                val reason = if (!hasInternet(appContext)) "No internet; offline mode." 
                    else "Internet is available, but cloud backend is not configured yet; offline mode."
                ChatResult(OfflineChatEngine.reply(appContext, message), Mode.OFFLINE, reason)
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post { callback(result) }
        }
    }

    private fun requestOnline(message: String): ChatResult? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(SAMAR_CHAT_ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            val body = JSONObject().put("message", message).toString()
            conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val reply = JSONObject(response).optString("reply").trim()
            if (reply.isBlank()) null else ChatResult(reply, Mode.ONLINE, "Cloud AI connected.")
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }
}
